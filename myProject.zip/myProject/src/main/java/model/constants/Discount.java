package model.constants;

public class Discount {
    public static final double ZERO = 0;
    public static final double SIXTY=60;
}
